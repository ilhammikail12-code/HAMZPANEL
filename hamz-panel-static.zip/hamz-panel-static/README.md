# HAMZ PANEL — Premium Website (Static)

Versi static siap upload ke **GitHub Pages**.

## Cara Upload ke GitHub

1. Buka repo kamu: https://github.com/ilhammikail12-code/HAMZPANEL
2. Upload / ganti file `index.html` dengan file `index.html` dari folder ini.
3. Commit & push.
4. Website otomatis update di:  
   **https://ilhammikail12-code.github.io/HAMZPANEL/**

Atau via terminal:

```bash
git clone https://github.com/ilhammikail12-code/HAMZPANEL.git
cd HAMZPANEL
# salin index.html baru ke sini
git add index.html
git commit -m "Update premium design"
git push
```

## Fitur

- Desain premium dark theme + electric blue
- Glassmorphism
- Animasi smooth (scroll reveal, floating, progress bar)
- Spesifikasi server real (Xeon Gold 6133, East Java)
- Pricing lengkap + link WhatsApp otomatis
- Reseller section
- Floating contact button
- Fully responsive
- Satu file saja (index.html) — mudah di-upload

## Kontak

- WhatsApp: +62 858-5744-0674
- Telegram: @HamzXfx

© 2026 HAMZ PANEL
