import { SITE, waLink, NAV, HERO_SERVERS, STATS, MARQUEE, PLANS, PLAN_FEATURES, SPEC_BLOCKS, INFRA, SECURITY, RESELLER } from "./data.js";
import { icon } from "./icons.js";

/* Semua tampilan dirender dari data. Edit data.js, bukan file ini. */

const rv = (d) => (d ? ` style="--d:${d}s"` : "");
const heading = (a, b, c = "") =>
  `<h2>${a} <span class="grad">${b}</span>${c ? " " + c : ""}</h2>`;
const secHead = (title, sub, pillHtml = "") =>
  `<div class="sec-head rv">${pillHtml}${title}<p>${sub}</p></div>`;

export function viewNav() {
  const links = NAV.map(([id, t]) => `<a href="#${id}">${t}</a>`).join("");
  const order = waLink("Halo Admin, saya ingin order panel");
  return `
  <header class="nav" id="nav"><div class="wrap">
    <div class="nav-in">
      <a href="#home" class="logo"><span class="logo-mark">${icon("server", "", "font-size:19px;color:#fff")}</span>HAMZ <b>PANEL</b></a>
      <nav class="links" id="links" aria-label="Navigasi utama"><span class="pillbg" id="pillbg"></span>${links}</nav>
      <a href="${order}" target="_blank" rel="noopener" class="btn btn-primary nav-cta" data-magnetic>Order now</a>
      <button class="burger" id="burger" aria-label="Buka menu" aria-expanded="false">${icon("menu")}</button>
    </div>
    <div class="mmenu" id="mmenu">${links}<a href="${order}" target="_blank" rel="noopener" class="btn btn-primary">Order now</a></div>
  </div></header>`;
}

export function viewHero() {
  const order = waLink("Halo Admin HAMZ PANEL, saya ingin order panel");
  const servers = HERO_SERVERS.map(
    (s) => `<div class="srv"><div class="srv-ic">${icon(s.icon)}</div><div class="srv-info"><b>${s.name}</b><small>${s.meta}</small></div><div class="led"><i></i><i></i><i></i><i></i><i></i></div><div class="srv-st"><span class="dot"></span>Running</div></div>`
  ).join("");
  return `
  <section class="hero" id="home"><div class="wrap hero-grid">
    <div>
      <div class="hero-badges hero-fade" style="--d:.2s">
        <span class="pill ok"><span class="dot"></span>Server ready</span>
        <span class="pill warn">${icon("shield")}30 days warranty</span>
      </div>
      <h1>
        <span class="ln"><span>Premium</span></span>
        <span class="ln"><span class="grad">Pterodactyl Panel</span></span>
        <span class="ln"><span>Hosting</span></span>
      </h1>
      <p class="hero-desc hero-fade" style="--d:.55s">Panel server powerful, stabil, dan siap digunakan untuk kebutuhan bot, website, game server, serta berbagai project kamu.</p>
      <p class="typed-line hero-fade" style="--d:.65s">Cocok untuk <em id="typed"></em><span class="caret"></span></p>
      <div class="hero-btns hero-fade" style="--d:.8s">
        <a href="${order}" target="_blank" rel="noopener" class="btn btn-primary" data-magnetic>Order now ${icon("arrow-right", "go")}</a>
        <a href="#specifications" class="btn btn-ghost" data-magnetic>Explore services</a>
      </div>
    </div>
    <div class="stage hero-fade" style="--d:.5s" id="stage">
      <div class="halo"></div>
      <canvas id="rack3d" class="rack3d" aria-label="Animasi rack server 3D"></canvas>
      <div class="chip c1">${icon("cpu")}Xeon Gold 6133</div>
      <div class="chip c2">${icon("zap")}I/O 722.7 MB/s</div>
      <div class="chip c3">${icon("shield")}Garansi 30 hari</div>
      <div class="livecard">
        <div class="rack-top"><i></i><i></i><i></i><span>servers (demo)</span></div>
        <div class="rack-body">${servers}
          <div class="rack-chart"><header><span>CPU usage</span><b id="rackVal">34%</b></header><canvas id="rackCv"></canvas></div>
        </div>
      </div>
    </div>
  </div></section>`;
}

export function viewStats() {
  const cards = STATS.map((s, i) => {
    const val = s.text
      ? s.text
      : `<span data-count="${s.count}" data-dec="${s.dec}">0</span>${s.suffix}`;
    return `<div class="stat card rv"${rv(i * 0.07)}>${icon(s.icon)}<div class="stat-v">${val}</div><div class="stat-l">${s.label}</div></div>`;
  }).join("");
  const tags = [...MARQUEE, ...MARQUEE]
    .map(([ic, t]) => `<span>${icon(ic)}${t}</span>`).join("");
  return `
  <section class="stats"><div class="wrap stats-grid">${cards}</div></section>
  <div class="marq" aria-hidden="true"><div class="marq-t">${tags}</div></div>`;
}

export function viewPricing() {
  const cards = PLANS.map((p, i) => {
    const msg = waLink(`Halo Admin HAMZ PANEL, saya ingin order paket ${p.name}`);
    const feats = PLAN_FEATURES(p).map((f) => `<li>${icon("check")}${f}</li>`).join("");
    return `<div class="plan card rv${p.best ? " best" : ""}" data-plan="${i}"${rv((i % 4) * 0.07)}>
      ${p.best ? '<span class="best-tag">Best value</span>' : ""}
      <div class="plan-name">${p.name}</div><div class="plan-price">${p.price}</div>
      <div class="plan-dur">30 Hari • Garansi 30 Hari</div>
      <ul>${feats}</ul>
      <a href="${msg}" target="_blank" rel="noopener" class="btn ${p.best ? "btn-primary" : "btn-ghost"}">Order now</a>
    </div>`;
  }).join("");
  const ticks = PLANS.map((p, i) => `<button type="button" class="tick" data-tick="${i}" aria-label="Pilih paket ${p.name}">${p.name.replace(" GB", "").replace("Unlimited", "∞")}</button>`).join("");
  return `
  <section class="sec" id="pricing"><div class="wrap">
    ${secHead(heading("Choose your", "perfect plan"), "Pilih paket panel sesuai kebutuhan project kamu dengan harga terjangkau.")}
    <div class="calc card rv">
      <div class="calc-l">
        <div class="calc-label">Geser untuk memilih RAM</div>
        <input type="range" id="calcRange" min="0" max="${PLANS.length - 1}" value="3" step="1" aria-label="Pilih paket RAM" />
        <div class="ticks" id="ticks">${ticks}</div>
      </div>
      <div class="calc-r">
        <div class="calc-name" id="calcName"></div>
        <div class="calc-price" id="calcPrice"></div>
        <div class="calc-dur">30 Hari • Garansi 30 Hari</div>
        <a id="calcBtn" href="#" target="_blank" rel="noopener" class="btn btn-primary" data-magnetic>Order paket ini ${icon("arrow-right", "go")}</a>
      </div>
    </div>
    <div class="pgrid" id="pgrid">${cards}</div>
  </div></section>`;
}

export function viewSpecs() {
  const blocks = SPEC_BLOCKS.map((b, i) =>
    `<div class="block card rv"${rv(i * 0.06)}><h3>${b.title}</h3><ul>${b.items.map((x) => `<li>${x}</li>`).join("")}</ul></div>`
  ).join("");
  return `
  <section class="sec" id="specifications" style="padding-top:2rem"><div class="wrap">
    ${secHead(heading("Real server", "specifications"), "Transparent infrastructure. Real performance.", `<span class="pill blue" style="margin-bottom:1rem">${icon("sparkles")}Real benchmark</span>`)}
    <div class="specs">
      <div class="term rv">
        <div class="term-bar"><i></i><i></i><i></i><span>bench.sh</span></div>
        <pre id="termOut" aria-label="Hasil benchmark server"></pre>
        <div class="term-foot"><span class="pill ok">${icon("check")}Real benchmark</span><span class="pill">Server information</span></div>
      </div>
      <div class="blocks">${blocks}</div>
    </div>
  </div></section>`;
}

const featGrid = (list) =>
  `<div class="fgrid">${list.map(([ic, t, d], i) =>
    `<div class="feat card rv"${rv((i % 3) * 0.06)}><div class="feat-ic">${icon(ic)}</div><h3>${t}</h3><p>${d}</p></div>`).join("")}</div>`;

export function viewInfra() {
  return `<section class="sec" style="padding-top:2rem"><div class="wrap">
    ${secHead(heading("Server", "infrastructure"), "Built on reliable enterprise hardware")}
    ${featGrid(INFRA)}</div></section>`;
}

export function viewReseller() {
  const perks = RESELLER.perks.map((p) => `<li>${icon("check")}${p}</li>`).join("");
  return `
  <section class="sec" id="reseller"><div class="wrap"><div class="reseller rv">
    <span class="pill warn">${icon("users")}Reseller program</span>
    <h2>Become our reseller</h2>
    <p>Mulai bisnis panel hosting kamu bersama HAMZ PANEL.</p>
    <div class="rprices">
      <div class="rbox"><div class="val">${RESELLER.signup}</div><div class="lbl">Harga pendaftaran</div></div>
      <div class="rbox"><div class="val">${RESELLER.monthly}</div><div class="lbl">Biaya bulanan</div></div>
    </div>
    <ul class="rlist">${perks}</ul>
    <a href="${waLink("Halo Admin, saya ingin join Reseller HAMZ PANEL")}" target="_blank" rel="noopener" class="btn btn-amber" data-magnetic>Join reseller ${icon("chevron-right", "go")}</a>
  </div></div></section>`;
}

export function viewSecurity() {
  return `<section class="sec" id="security" style="border-block:1px solid var(--line)"><div class="wrap">
    ${secHead(heading("Security &amp;", "features"), "Infrastructure focused on reliability and transparency")}
    ${featGrid(SECURITY)}</div></section>`;
}

export function viewDashboard() {
  return `
  <section class="sec"><div class="wrap">
    ${secHead(heading("Server", "dashboard"), "Simulated Pterodactyl-style resource monitor", '<span class="pill" style="margin-bottom:1rem">Demo preview</span>')}
    <div class="dash card rv" id="dash">
      <div class="dash-top"><span style="display:flex;align-items:center;gap:.55rem;color:var(--ok)"><span class="dot"></span><span style="color:var(--text)">Server console (demo)</span></span><span>Uptime simulation</span></div>
      <div class="dbars">
        <div class="dbox"><div class="dlab"><span>CPU usage</span><b id="vCpu">34%</b></div><div class="dtrack"><div class="dfill" id="bCpu"></div></div></div>
        <div class="dbox"><div class="dlab"><span>Memory</span><b id="vMem">2%</b></div><div class="dtrack"><div class="dfill" id="bMem"></div></div><div class="dsub">1.4 / 62.8 GB</div></div>
        <div class="dbox"><div class="dlab"><span>Disk</span><b>5%</b></div><div class="dtrack"><div class="dfill" id="bDisk"></div></div><div class="dsub">12.4 / 249.5 GB</div></div>
      </div>
      <div class="dmid">
        <div class="dchart"><div class="dlab"><span>CPU history</span><b>60 detik</b></div><canvas id="dashCv"></canvas></div>
        <div class="consolebox" id="cons"></div>
      </div>
      <div class="dstats">
        <div class="dst"><b id="vIn">128 Mbps</b><small>Network in</small></div>
        <div class="dst"><b id="vOut">94 Mbps</b><small>Network out</small></div>
        <div class="dst"><b>Demo</b><small>Uptime</small></div>
        <div class="dst"><b>0.04</b><small>Load</small></div>
      </div>
    </div>
  </div></section>`;
}

export function viewChannels() {
  return `<section class="sec" style="padding-top:1rem"><div class="wrap chgrid">
    <a href="${SITE.channels.testimonials}" target="_blank" rel="noopener" class="chcard card rv">
      <div class="row"><div class="chic" style="background:rgba(61,220,151,.12);color:var(--ok)">${icon("message-circle")}</div><div><h3>Customer testimonials</h3><p>Lihat pengalaman pelanggan</p></div></div>
      <span class="chlink">View testimonials ${icon("external-link")}</span></a>
    <a href="${SITE.channels.products}" target="_blank" rel="noopener" class="chcard card rv" style="--d:.08s">
      <div class="row"><div class="chic" style="background:rgba(88,184,255,.12);color:var(--sky)">${icon("star")}</div><div><h3>All product channel</h3><p>Update &amp; promo terbaru</p></div></div>
      <span class="chlink">Join channel ${icon("external-link")}</span></a>
  </div></section>`;
}

export function viewContact() {
  return `
  <section class="sec" id="contact"><div class="wrap">
    ${secHead(heading("Ready to", "order?"), "Pilih paket panel yang sesuai kebutuhan kamu dan langsung hubungi admin HAMZ PANEL.")}
    <div class="cgrid">
      <a href="${waLink("mas mau order panel")}" target="_blank" rel="noopener" class="ccard card wa rv">${icon("message-circle", "big", "color:var(--ok)")}<h3>WhatsApp Admin</h3><div class="num">${SITE.waLabel}</div><span class="cta" style="color:var(--ok)">Order via WhatsApp</span></a>
      <a href="https://t.me/${SITE.tg}" target="_blank" rel="noopener" class="ccard card tg rv" style="--d:.08s">${icon("send", "big", "color:#38bdf8")}<h3>Telegram Admin</h3><div class="num">@${SITE.tg}</div><span class="cta" style="color:#38bdf8">Chat via Telegram</span></a>
    </div>
  </div></section>`;
}

export function viewFooter() {
  return `
  <footer><div class="wrap">
    <div class="fgrid2">
      <div class="fbrand"><a href="#home" class="logo"><span class="logo-mark" style="width:34px;height:34px">${icon("server", "", "font-size:17px;color:#fff")}</span>HAMZ <b>PANEL</b></a><p>Premium Panel Hosting Infrastructure.</p></div>
      <div class="fcol"><h4>Navigate</h4>${NAV.filter(([id]) => id !== "security").map(([id, t]) => `<a href="#${id}">${t}</a>`).join("")}</div>
      <div class="fcol"><h4>Contact</h4><a href="${waLink("Halo")}" target="_blank" rel="noopener">WhatsApp Admin</a><a href="https://t.me/${SITE.tg}" target="_blank" rel="noopener">Telegram Admin</a></div>
      <div class="fcol"><h4>Channels</h4><a href="${SITE.channels.testimonials}" target="_blank" rel="noopener">Testimoni</a><a href="${SITE.channels.products}" target="_blank" rel="noopener">All Produk</a></div>
    </div>
    <div class="fcopy">© ${SITE.year} HAMZ PANEL. All Rights Reserved.</div>
  </div></footer>
  <div class="fab-wrap">
    <button class="totop" id="totop" aria-label="Kembali ke atas">${icon("arrow-up")}</button>
    <div class="fmenu" id="fmenu">
      <a href="${waLink("Halo Admin HAMZ PANEL")}" target="_blank" rel="noopener">${icon("message-circle", "", "color:var(--ok);font-size:18px")}WhatsApp Admin</a>
      <a href="https://t.me/${SITE.tg}" target="_blank" rel="noopener">${icon("send", "", "color:#38bdf8;font-size:18px")}Telegram Admin</a>
    </div>
    <button class="fab" id="fab" aria-label="Hubungi admin" aria-expanded="false">${icon("message-circle", "m")}${icon("x", "x")}</button>
  </div>`;
}

export function viewLayers() {
  return `
  <div id="loader" aria-hidden="true"><div class="ld-logo">H</div><div class="ld-bar"><b></b></div><div class="ld-txt">menyiapkan server…</div></div>
  <canvas id="net" aria-hidden="true"></canvas>
  <div class="aurora" aria-hidden="true"><i></i><i></i><i></i></div>
  <div class="grid-bg" aria-hidden="true"></div>
  <div class="grain" aria-hidden="true"></div>
  <div class="cursor-glow" id="glow" aria-hidden="true"></div>
  <div class="progress" id="progress"></div>`;
}
