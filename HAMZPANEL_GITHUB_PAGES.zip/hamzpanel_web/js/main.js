import { viewLayers, viewNav, viewHero, viewStats, viewPricing, viewSpecs, viewInfra, viewReseller, viewSecurity, viewDashboard, viewChannels, viewContact, viewFooter } from "./ui.js";
import { fxLoader, fxScroll, fxMenus, fxNavPill, fxReveal, fxCounters, fxPointer, fxTyped, fxTerminal, fxCalc, fxMetrics, fxNetwork, fxRack3D } from "./fx.js";

/* Titik masuk: render semua bagian, lalu aktifkan efek. */
function mountApp() {
  document.documentElement.classList.add("js");
  document.body.classList.add("loading");
  const app = document.getElementById("app");
  app.innerHTML =
    viewLayers() +
    viewNav() +
    "<main>" +
    [viewHero, viewStats, viewPricing, viewSpecs, viewInfra, viewReseller, viewSecurity, viewDashboard, viewChannels, viewContact].map((v) => v()).join("") +
    "</main>" +
    viewFooter();

  fxLoader();
  fxScroll();
  fxMenus();
  fxNavPill();
  fxReveal();
  fxCounters();
  fxPointer();
  fxTyped();
  fxTerminal();
  fxCalc();
  fxMetrics();
  fxNetwork();
  fxRack3D();
}

mountApp();
