import { TYPED, BENCH, DEMO_LOGS, PLANS, waLink } from "./data.js";
import { icon } from "./icons.js";

/* Semua efek visual & interaksi. Tiap fungsi berdiri sendiri. */

const RM = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const FINE = window.matchMedia("(pointer: fine)").matches;
const qs = (s, c = document) => c.querySelector(s);
const qsa = (s, c = document) => Array.from(c.querySelectorAll(s));

/* ---------- Loader ---------- */
export function fxLoader() {
  const t0 = Date.now();
  const end = () => {
    const l = qs("#loader");
    if (!l || l.classList.contains("done")) return;
    l.classList.add("done");
    document.body.classList.remove("loading");
    setTimeout(() => l.remove(), 1000);
  };
  window.addEventListener("load", () => setTimeout(end, Math.max(0, 1100 - (Date.now() - t0))));
  setTimeout(end, 2600);
}

/* ---------- Scroll: progress, navbar, to-top ---------- */
export function fxScroll() {
  const nav = qs("#nav"), prog = qs("#progress"), top = qs("#totop");
  const on = () => {
    const y = window.scrollY, h = document.documentElement.scrollHeight - window.innerHeight;
    nav.classList.toggle("scrolled", y > 20);
    prog.style.transform = `scaleX(${h > 0 ? y / h : 0})`;
    top.classList.toggle("show", y > 700);
  };
  window.addEventListener("scroll", on, { passive: true });
  on();
  top.addEventListener("click", () => window.scrollTo({ top: 0, behavior: RM ? "auto" : "smooth" }));
}

/* ---------- Menu mobile + tombol kontak melayang ---------- */
export function fxMenus() {
  const burger = qs("#burger"), mm = qs("#mmenu");
  burger.addEventListener("click", () => {
    const o = mm.classList.toggle("open");
    burger.setAttribute("aria-expanded", o);
  });
  qsa("a", mm).forEach((a) => a.addEventListener("click", () => {
    mm.classList.remove("open");
    burger.setAttribute("aria-expanded", false);
  }));
  const fab = qs("#fab"), fm = qs("#fmenu");
  fab.addEventListener("click", () => {
    const o = fm.classList.toggle("open");
    fab.classList.toggle("open", o);
    fab.setAttribute("aria-expanded", o);
  });
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".fab-wrap")) { fm.classList.remove("open"); fab.classList.remove("open"); }
  });
}

/* ---------- Pil navigasi yang bergeser + scrollspy ---------- */
export function fxNavPill() {
  const links = qs("#links"), pill = qs("#pillbg"), items = qsa("a", links);
  let current = null;
  const move = (a) => {
    if (!a) { pill.style.opacity = 0; return; }
    pill.style.opacity = 1;
    pill.style.left = a.offsetLeft + "px";
    pill.style.width = a.offsetWidth + "px";
  };
  items.forEach((a) => {
    a.addEventListener("mouseenter", () => move(a));
    a.addEventListener("focus", () => move(a));
  });
  links.addEventListener("mouseleave", () => move(current));
  const spy = new IntersectionObserver((es) => es.forEach((e) => {
    if (!e.isIntersecting) return;
    items.forEach((a) => {
      const on = a.getAttribute("href") === "#" + e.target.id;
      a.classList.toggle("act", on);
      if (on) { current = a; move(a); }
    });
  }), { rootMargin: "-45% 0px -50% 0px" });
  items.forEach((a) => { const el = qs(a.getAttribute("href")); if (el) spy.observe(el); });
  window.addEventListener("resize", () => move(current));
}

/* ---------- Reveal saat scroll ---------- */
export function fxReveal() {
  const obs = new IntersectionObserver((es) => es.forEach((e) => {
    if (e.isIntersecting) { e.target.classList.add("in"); obs.unobserve(e.target); }
  }), { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  qsa(".rv").forEach((el) => obs.observe(el));
  setTimeout(() => qsa(".rv:not(.in)").forEach((el) => {
    if (el.getBoundingClientRect().top < window.innerHeight) el.classList.add("in");
  }), 2800);
}

/* ---------- Angka naik ---------- */
export function fxCounters() {
  const obs = new IntersectionObserver((es) => es.forEach((e) => {
    if (!e.isIntersecting) return;
    obs.unobserve(e.target);
    const el = e.target, to = parseFloat(el.dataset.count), dec = +el.dataset.dec || 0;
    const dur = RM ? 1 : 1600, s = performance.now();
    const step = (n) => {
      const p = Math.min(1, (n - s) / dur);
      el.textContent = (to * (1 - Math.pow(1 - p, 3))).toFixed(dec);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }), { threshold: 0.6 });
  qsa("[data-count]").forEach((el) => obs.observe(el));
}

/* ---------- Spotlight kartu, cursor glow, tombol magnetik, ripple ---------- */
export function fxPointer() {
  document.addEventListener("pointermove", (e) => {
    const c = e.target.closest && e.target.closest(".card");
    if (c) {
      const r = c.getBoundingClientRect();
      c.style.setProperty("--mx", e.clientX - r.left + "px");
      c.style.setProperty("--my", e.clientY - r.top + "px");
    }
  }, { passive: true });

  const glow = qs("#glow");
  if (FINE && !RM) {
    let gx = 0, gy = 0, tx = 0, ty = 0;
    document.addEventListener("pointermove", (e) => { tx = e.clientX; ty = e.clientY; glow.classList.add("on"); }, { passive: true });
    document.addEventListener("mouseleave", () => glow.classList.remove("on"));
    const loop = () => {
      gx += (tx - gx) * 0.12; gy += (ty - gy) * 0.12;
      glow.style.transform = `translate(${gx}px,${gy}px)`;
      requestAnimationFrame(loop);
    };
    loop();
    qsa("[data-magnetic]").forEach((b) => {
      b.addEventListener("pointermove", (e) => {
        const r = b.getBoundingClientRect();
        b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.22}px,${(e.clientY - r.top - r.height / 2) * 0.3}px)`;
      });
      b.addEventListener("pointerleave", () => { b.style.transform = ""; });
    });
  }

  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".btn");
    if (!b) return;
    const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height);
    const sp = document.createElement("span");
    sp.className = "ripple";
    sp.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
    b.appendChild(sp);
    setTimeout(() => sp.remove(), 700);
  });
}

/* ---------- Teks mengetik di hero ---------- */
export function fxTyped() {
  const el = qs("#typed");
  if (RM) { el.textContent = TYPED.join(", "); return; }
  let wi = 0, ci = 0, del = false;
  const type = () => {
    const w = TYPED[wi];
    el.textContent = w.slice(0, ci);
    if (!del && ci < w.length) { ci++; setTimeout(type, 70); }
    else if (!del) { del = true; setTimeout(type, 1500); }
    else if (ci > 0) { ci--; setTimeout(type, 35); }
    else { del = false; wi = (wi + 1) % TYPED.length; setTimeout(type, 300); }
  };
  type();
}

/* ---------- Terminal benchmark mengetik sendiri ---------- */
export function fxTerminal() {
  const out = qs("#termOut");
  const lines = BENCH.map((l) => l[0] === "k"
    ? `<span class="k">${l[1]}</span>${l[2]}`
    : `<span class="${l[0]}">${l[1]}</span>`);
  const render = (n) => { out.innerHTML = lines.slice(0, n).join("\n") + '\n<span class="cur"></span>'; };
  if (RM) { out.innerHTML = lines.join("\n"); return; }
  render(0);
  let started = false;
  new IntersectionObserver((es, o) => es.forEach((e) => {
    if (!e.isIntersecting || started) return;
    started = true; o.disconnect();
    let n = 0;
    const next = () => { n++; render(n); if (n < lines.length) setTimeout(next, 380); };
    next();
  }), { threshold: 0.35 }).observe(out);
}

/* ---------- Kalkulator paket (slider) ---------- */
export function fxCalc() {
  const range = qs("#calcRange"), name = qs("#calcName"), price = qs("#calcPrice"), btn = qs("#calcBtn");
  const ticks = qsa("[data-tick]"), cards = qsa("[data-plan]");
  const set = (i) => {
    const p = PLANS[i];
    range.value = i;
    range.style.setProperty("--pct", (i / (PLANS.length - 1)) * 100 + "%");
    name.textContent = p.name === "Unlimited" ? "Paket Unlimited" : `Paket ${p.name} RAM`;
    price.classList.remove("pop"); void price.offsetWidth; price.classList.add("pop");
    price.textContent = p.price;
    btn.href = waLink(`Halo Admin HAMZ PANEL, saya ingin order paket ${p.name}`);
    ticks.forEach((t, k) => t.classList.toggle("on", k === i));
    cards.forEach((c, k) => c.classList.toggle("sel", k === i));
  };
  range.addEventListener("input", () => set(+range.value));
  ticks.forEach((t) => t.addEventListener("click", () => set(+t.dataset.tick)));
  cards.forEach((c) => c.addEventListener("click", (e) => { if (!e.target.closest("a")) set(+c.dataset.plan); }));
  set(+range.value);
}

/* ---------- Grafik kecil & metrik live (demo) ---------- */
function fit(cv) {
  const d = Math.min(window.devicePixelRatio || 1, 2), r = cv.getBoundingClientRect();
  cv.width = Math.max(1, r.width * d); cv.height = Math.max(1, r.height * d);
  const c = cv.getContext("2d");
  c.setTransform(d, 0, 0, d, 0, 0);
  return { c, w: r.width, h: r.height };
}
function spark(cv, data, stroke, fill) {
  const { c, w, h } = fit(cv);
  c.clearRect(0, 0, w, h);
  c.strokeStyle = "rgba(120,170,255,.08)"; c.lineWidth = 1;
  for (let i = 1; i < 4; i++) { c.beginPath(); c.moveTo(0, (h * i) / 4); c.lineTo(w, (h * i) / 4); c.stroke(); }
  const st = w / (data.length - 1);
  const pts = data.map((v, i) => [i * st, h - (v / 100) * (h - 6) - 3]);
  const path = () => { c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); };
  path();
  const g = c.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, fill); g.addColorStop(1, "rgba(47,107,255,0)");
  c.lineTo(w, h); c.lineTo(0, h); c.closePath(); c.fillStyle = g; c.fill();
  path(); c.strokeStyle = stroke; c.lineWidth = 2; c.lineJoin = "round"; c.stroke();
  const l = pts[pts.length - 1];
  c.beginPath(); c.arc(l[0] - 2, l[1], 3.5, 0, 6.283); c.fillStyle = "#fff";
  c.shadowColor = stroke; c.shadowBlur = 10; c.fill(); c.shadowBlur = 0;
}

export function fxMetrics() {
  const cpu = [], rk = [];
  for (let i = 0; i < 60; i++) cpu.push(30 + Math.sin(i / 5) * 6 + Math.random() * 6);
  for (let i = 0; i < 40; i++) rk.push(32 + Math.sin(i / 4) * 8 + Math.random() * 5);
  const rackCv = qs("#rackCv"), dashCv = qs("#dashCv");
  const draw = () => {
    spark(rackCv, rk, "#00d4ff", "rgba(0,212,255,.35)");
    spark(dashCv, cpu, "#58b8ff", "rgba(47,107,255,.4)");
  };
  draw();
  window.addEventListener("resize", draw);

  let dashVisible = false, heroVisible = true, seen = false;
  const bCpu = qs("#bCpu"), bMem = qs("#bMem"), bDisk = qs("#bDisk");
  new IntersectionObserver((es) => { dashVisible = es[0].isIntersecting; }, { threshold: 0.1 }).observe(qs("#dash"));
  new IntersectionObserver((es) => { heroVisible = es[0].isIntersecting; }).observe(qs("#home"));
  new IntersectionObserver((es, o) => {
    if (es[0].isIntersecting) { seen = true; bCpu.style.width = "34%"; bMem.style.width = "2%"; bDisk.style.width = "5%"; o.disconnect(); }
  }, { threshold: 0.3 }).observe(qs("#dash"));

  const cons = qs("#cons");
  let li = 0;
  const addLog = () => {
    const l = DEMO_LOGS[li++ % DEMO_LOGS.length], d = document.createElement("div");
    d.innerHTML = `<span class="${l[0]}">${l[1]}</span> ${l[2]}`;
    cons.appendChild(d);
    while (cons.children.length > 7) cons.removeChild(cons.firstChild);
  };
  for (let i = 0; i < 5; i++) addLog();

  if (RM) return;
  setInterval(() => {
    if (document.hidden) return;
    const v = Math.max(12, Math.min(78, cpu[cpu.length - 1] + (Math.random() - 0.5) * 10));
    cpu.push(v); cpu.shift(); rk.push(v); rk.shift();
    if (heroVisible) { draw(); qs("#rackVal").textContent = Math.round(v) + "%"; }
    if (dashVisible) {
      draw();
      if (seen) bCpu.style.width = v.toFixed(0) + "%";
      qs("#vCpu").textContent = Math.round(v) + "%";
      qs("#vMem").textContent = Math.max(1, Math.round((1.4 / 62.8) * 100 + Math.random())) + "%";
      qs("#vIn").textContent = Math.round(110 + Math.random() * 40) + " Mbps";
      qs("#vOut").textContent = Math.round(80 + Math.random() * 30) + " Mbps";
    }
  }, 1100);
  setInterval(() => { if (dashVisible && !document.hidden) addLog(); }, 1700);
}

/* ---------- Jaring partikel di latar ---------- */
export function fxNetwork() {
  const cv = qs("#net");
  if (!cv || RM) return;
  const c = cv.getContext("2d"), D = Math.min(window.devicePixelRatio || 1, 1.5);
  let W = 0, H = 0, pts = [];
  const mouse = { x: -999, y: -999 };
  const size = () => {
    W = window.innerWidth; H = window.innerHeight;
    cv.width = W * D; cv.height = H * D; c.setTransform(D, 0, 0, D, 0, 0);
    const n = Math.min(90, Math.floor((W * H) / 17000));
    pts = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - 0.5) * 0.28, vy: (Math.random() - 0.5) * 0.28, r: Math.random() * 1.4 + 0.5 }));
  };
  size();
  window.addEventListener("resize", size);
  document.addEventListener("pointermove", (e) => { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
  const draw = () => {
    if (!document.hidden) {
      c.clearRect(0, 0, W, H);
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > W) p.vx *= -1;
        if (p.y < 0 || p.y > H) p.vy *= -1;
        const dx = mouse.x - p.x, dy = mouse.y - p.y, dm = Math.hypot(dx, dy);
        if (dm < 160) { p.x -= dx * 0.004; p.y -= dy * 0.004; }
        c.beginPath(); c.arc(p.x, p.y, p.r, 0, 6.283); c.fillStyle = "rgba(120,190,255,.65)"; c.fill();
        for (let j = i + 1; j < pts.length; j++) {
          const q = pts[j], ax = p.x - q.x, ay = p.y - q.y, d = ax * ax + ay * ay;
          if (d < 14400) {
            c.strokeStyle = `rgba(70,140,255,${0.22 * (1 - d / 14400)})`; c.lineWidth = 1;
            c.beginPath(); c.moveTo(p.x, p.y); c.lineTo(q.x, q.y); c.stroke();
          }
        }
        if (dm < 170) {
          c.strokeStyle = `rgba(0,212,255,${0.35 * (1 - dm / 170)})`;
          c.beginPath(); c.moveTo(p.x, p.y); c.lineTo(mouse.x, mouse.y); c.stroke();
        }
      }
    }
    requestAnimationFrame(draw);
  };
  draw();
}

/* ---------- Rack server 3D (canvas, tanpa library) ---------- */
export function fxRack3D() {
  const cv = qs("#rack3d"), stage = qs("#stage");
  if (!cv) return;
  const UNITS = 8, HW = 1.45, HH = 0.17, HD = 0.9, GAP = 0.47;
  let W = 0, H = 0, D = 1, visible = true, mx = 0, my = 0, tmx = 0, tmy = 0;
  const ctx = cv.getContext("2d");
  const resize = () => {
    D = Math.min(window.devicePixelRatio || 1, 2);
    const r = cv.getBoundingClientRect();
    W = r.width; H = r.height;
    cv.width = W * D; cv.height = H * D; ctx.setTransform(D, 0, 0, D, 0, 0);
  };
  resize();
  window.addEventListener("resize", resize);
  new IntersectionObserver((es) => { visible = es[0].isIntersecting; }).observe(cv);
  stage.addEventListener("pointermove", (e) => {
    const r = stage.getBoundingClientRect();
    tmx = (e.clientX - r.left) / r.width - 0.5;
    tmy = (e.clientY - r.top) / r.height - 0.5;
    stage.style.setProperty("--px", tmx.toFixed(3));
    stage.style.setProperty("--py", tmy.toFixed(3));
  });
  stage.addEventListener("pointerleave", () => { tmx = 0; tmy = 0; stage.style.setProperty("--px", 0); stage.style.setProperty("--py", 0); });

  // transform + proyeksi
  let ang = 0, pit = 0.3;
  const CAM = 7.2;
  const tf = (x, y, z) => {
    const ca = Math.cos(ang), sa = Math.sin(ang);
    let X = x * ca + z * sa, Z = -x * sa + z * ca, Y = y;
    const cp = Math.cos(pit), sp = Math.sin(pit);
    const Y2 = Y * cp - Z * sp, Z2 = Y * sp + Z * cp;
    return [X, Y2, Z2];
  };
  const pj = (v) => {
    const s = (Math.min(W, H) * 1.12) / (CAM - v[2]);
    return [W * 0.45 + v[0] * s, H * 0.46 - v[1] * s, s];
  };
  const P = (x, y, z) => pj(tf(x, y, z));
  const lerp2 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
  const quadPt = (q, u, v) => {
    const top = lerp2(q[0], q[1], u), bot = lerp2(q[3], q[2], u);
    return lerp2(top, bot, v);
  };
  const fill = (q, color) => {
    ctx.beginPath(); ctx.moveTo(q[0][0], q[0][1]);
    for (let i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]);
    ctx.closePath(); ctx.fillStyle = color; ctx.fill();
  };
  const edge = (q, color, w = 1) => {
    ctx.beginPath(); ctx.moveTo(q[0][0], q[0][1]);
    for (let i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]);
    ctx.closePath(); ctx.strokeStyle = color; ctx.lineWidth = w; ctx.stroke();
  };

  const drawUnit = (idx, y0, t) => {
    const cx = 0, cz = 0;
    const faces = [
      { n: [0, 0, 1],  v: [[-HW, HH, HD], [HW, HH, HD], [HW, -HH, HD], [-HW, -HH, HD]], k: "front" },
      { n: [0, 0, -1], v: [[HW, HH, -HD], [-HW, HH, -HD], [-HW, -HH, -HD], [HW, -HH, -HD]], k: "back" },
      { n: [1, 0, 0],  v: [[HW, HH, HD], [HW, HH, -HD], [HW, -HH, -HD], [HW, -HH, HD]], k: "side" },
      { n: [-1, 0, 0], v: [[-HW, HH, -HD], [-HW, HH, HD], [-HW, -HH, HD], [-HW, -HH, -HD]], k: "side" },
      { n: [0, 1, 0],  v: [[-HW, HH, -HD], [HW, HH, -HD], [HW, HH, HD], [-HW, HH, HD]], k: "top" },
      { n: [0, -1, 0], v: [[-HW, -HH, HD], [HW, -HH, HD], [HW, -HH, -HD], [-HW, -HH, -HD]], k: "bot" },
    ];
    const centerT = tf(cx, y0, cz);
    for (const f of faces) {
      const nT = tf(f.n[0] + 0, f.n[1] + y0 * 0, f.n[2]); // arah normal (rotasi saja)
      const nv = [nT[0] - tf(0, 0, 0)[0], nT[1] - tf(0, 0, 0)[1], nT[2] - tf(0, 0, 0)[2]];
      // posisi pusat wajah
      const fc = tf(f.n[0] * (f.n[0] ? HW : 0), y0 + f.n[1] * HH, f.n[2] * (f.n[2] ? HD : 0));
      const view = [0 - fc[0], 0 - fc[1], CAM - fc[2]];
      if (nv[0] * view[0] + nv[1] * view[1] + nv[2] * view[2] <= 0) continue;
      const q = f.v.map((p) => P(p[0], p[1] + y0, p[2]));
      if (f.k === "front") {
        fill(q, "rgba(11,17,36,.96)");
        // strip cahaya atas
        const a = quadPt(q, 0.03, 0.12), b = quadPt(q, 0.97, 0.12), c2 = quadPt(q, 0.97, 0.22), d = quadPt(q, 0.03, 0.22);
        fill([a, b, c2, d], "rgba(47,107,255,.35)");
        // ventilasi
        ctx.strokeStyle = "rgba(120,170,255,.22)"; ctx.lineWidth = 1;
        for (let k = 0; k < 7; k++) {
          const u = 0.42 + k * 0.075;
          const p1 = quadPt(q, u, 0.4), p2 = quadPt(q, u, 0.85);
          ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p2[0], p2[1]); ctx.stroke();
        }
        // LED
        for (let k = 0; k < 4; k++) {
          const on = Math.sin(t * (1.5 + (idx % 3) * 0.7) + idx * 1.7 + k * 2.3) > -0.2;
          const col = k === 0 ? "61,220,151" : k === 3 && idx % 3 === 0 ? "255,181,71" : "0,212,255";
          const p = quadPt(q, 0.07 + k * 0.06, 0.62);
          ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(1.4, q[0][2] * 0.045), 0, 6.283);
          ctx.fillStyle = on ? `rgba(${col},.95)` : `rgba(${col},.18)`;
          if (on) { ctx.shadowColor = `rgba(${col},1)`; ctx.shadowBlur = 8; }
          ctx.fill(); ctx.shadowBlur = 0;
        }
        edge(q, "rgba(88,184,255,.55)", 1.1);
      } else if (f.k === "top") {
        fill(q, "rgba(24,40,82,.92)"); edge(q, "rgba(88,184,255,.5)");
      } else if (f.k === "bot") {
        fill(q, "rgba(6,9,18,.95)"); edge(q, "rgba(88,184,255,.25)");
      } else {
        fill(q, f.k === "back" ? "rgba(7,11,22,.96)" : "rgba(9,14,30,.95)"); edge(q, "rgba(88,184,255,.35)");
      }
    }
  };

  const floor = (t) => {
    const y = -(UNITS * GAP) / 2 - 0.35;
    ctx.lineWidth = 1;
    for (let i = -5; i <= 5; i++) {
      const a = P(i * 0.8, y, -4), b = P(i * 0.8, y, 4), c = P(-4, y, i * 0.8), d = P(4, y, i * 0.8);
      const al = 0.16 * (1 - Math.abs(i) / 6);
      ctx.strokeStyle = `rgba(88,184,255,${al})`;
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.stroke();
    }
    // gelombang pulsa di lantai
    const r = ((t * 0.5) % 1) * 3.6;
    ctx.strokeStyle = `rgba(0,212,255,${0.35 * (1 - r / 3.6)})`; ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let k = 0; k <= 48; k++) {
      const a = (k / 48) * 6.283, p = P(Math.cos(a) * r, y, Math.sin(a) * r);
      k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]);
    }
    ctx.stroke();
  };

  const orbit = (t, front) => {
    const R = 3.1, yy = 0.2;
    // cincin
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(88,184,255,.14)";
    ctx.beginPath();
    let pen = false;
    for (let k = 0; k <= 80; k++) {
      const a = (k / 80) * 6.283, v = tf(Math.cos(a) * R, yy, Math.sin(a) * R);
      if ((v[2] > 0) !== front) { pen = false; continue; }
      const p = pj(v);
      if (pen) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]);
      pen = true;
    }
    ctx.stroke();
    // titik data bergerak
    for (let k = 0; k < 3; k++) {
      const a = t * 0.9 + (k * 6.283) / 3, v = tf(Math.cos(a) * R, yy + Math.sin(a * 2) * 0.25, Math.sin(a) * R);
      if ((v[2] > 0) !== front) continue;
      const p = pj(v);
      ctx.beginPath(); ctx.arc(p[0], p[1], 3, 0, 6.283); ctx.fillStyle = "#59c0ff"; ctx.shadowColor = "#00d4ff"; ctx.shadowBlur = 14; ctx.fill(); ctx.shadowBlur = 0;
    }
  };

  const packets = (t) => {
    const top = (UNITS * GAP) / 2 + 0.2, bot = -top;
    for (let k = 0; k < 5; k++) {
      const f = (t * 0.35 + k / 5) % 1, y = bot + (top - bot) * f;
      const p = P(HW + 0.18, y, HD + 0.12);
      ctx.beginPath(); ctx.arc(p[0], p[1], 2.2, 0, 6.283);
      ctx.fillStyle = `rgba(0,212,255,${0.9 * Math.sin(f * 3.1416)})`; ctx.shadowColor = "#00d4ff"; ctx.shadowBlur = 10; ctx.fill(); ctx.shadowBlur = 0;
    }
  };

  const t0 = performance.now();
  const frame = (now) => {
    requestAnimationFrame(frame);
    if (!visible || document.hidden) return;
    const t = (now - t0) / 1000;
    mx += (tmx - mx) * 0.06; my += (tmy - my) * 0.06;
    ang = (RM ? 0.6 : t * 0.32) + mx * 1.1;
    pit = 0.3 + my * 0.35;
    ctx.clearRect(0, 0, W, H);
    // aura di belakang rack
    const g = ctx.createRadialGradient(W / 2, H / 2, 10, W / 2, H / 2, Math.min(W, H) * 0.55);
    g.addColorStop(0, "rgba(47,107,255,.22)"); g.addColorStop(1, "rgba(47,107,255,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    floor(t);
    orbit(t, false);
    const order = [];
    for (let i = 0; i < UNITS; i++) {
      const y0 = (i - (UNITS - 1) / 2) * GAP;
      order.push({ i, y0, z: tf(0, y0, 0)[2] });
    }
    order.sort((a, b) => a.z - b.z);
    order.forEach((o) => drawUnit(o.i, o.y0, t));
    packets(t);
    orbit(t, true);
  };
  requestAnimationFrame(frame);
}
