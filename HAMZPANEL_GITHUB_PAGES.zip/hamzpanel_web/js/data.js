/* =====================================================
   HAMZ PANEL — DATA
   Edit harga, kontak, dan spesifikasi cukup di file ini.
   ===================================================== */

export const SITE = {
  brand: "HAMZ PANEL",
  wa: "6285857440674",
  waLabel: "+62 858-5744-0674",
  tg: "HamzXfx",
  channels: {
    testimonials: "https://whatsapp.com/channel/0029Vb7rFYD5Ejy45AXEeR2M",
    products: "https://whatsapp.com/channel/0029Vb8gbCaHFxPBCmU7h03o",
  },
  year: 2026,
};

export const waLink = (text) =>
  `https://wa.me/${SITE.wa}?text=${encodeURIComponent(text)}`;

export const NAV = [
  ["home", "Home"],
  ["pricing", "Pricing"],
  ["specifications", "Specifications"],
  ["reseller", "Reseller"],
  ["security", "Security"],
  ["contact", "Contact"],
];

export const TYPED = [
  "bot WhatsApp",
  "bot Telegram",
  "website toko",
  "game server",
  "project kamu",
];

export const HERO_SERVERS = [
  { icon: "message-circle", name: "bot-whatsapp", meta: "Node.js · 1 GB" },
  { icon: "box", name: "minecraft-smp", meta: "Java · 8 GB" },
  { icon: "monitor", name: "website-toko", meta: "Nginx · 2 GB" },
];

export const STATS = [
  { icon: "cpu", count: 8, dec: 0, suffix: " Cores", label: "Intel Xeon Gold 6133" },
  { icon: "layers", count: 62.8, dec: 1, suffix: " GB", label: "Total RAM" },
  { icon: "hard-drive", count: 249.5, dec: 1, suffix: " GB", label: "Storage" },
  { icon: "box", text: "VMware", label: "Virtualization" },
  { icon: "map-pin", text: "East Java", label: "Madiun, Indonesia" },
];

export const MARQUEE = [
  ["terminal", "Node.js"], ["message-circle", "Bot WhatsApp"], ["send", "Bot Telegram"],
  ["gamepad", "Minecraft"], ["globe", "Website"], ["box", "Docker"],
  ["server", "Pterodactyl"], ["monitor", "Ubuntu 24.04"], ["cpu", "Xeon Gold"], ["zap", "Python"],
];

/* name, harga, RAM, CPU, best? */
export const PLANS = [
  { name: "1 GB", price: "Rp2.000", ram: "1 GB", cpu: "Shared" },
  { name: "2 GB", price: "Rp3.000", ram: "2 GB", cpu: "Shared" },
  { name: "3 GB", price: "Rp5.000", ram: "3 GB", cpu: "Shared" },
  { name: "4 GB", price: "Rp7.000", ram: "4 GB", cpu: "Shared" },
  { name: "5 GB", price: "Rp8.000", ram: "5 GB", cpu: "Shared" },
  { name: "6 GB", price: "Rp10.000", ram: "6 GB", cpu: "Shared" },
  { name: "7 GB", price: "Rp12.000", ram: "7 GB", cpu: "Shared" },
  { name: "8 GB", price: "Rp15.000", ram: "8 GB", cpu: "Shared" },
  { name: "9 GB", price: "Rp18.000", ram: "9 GB", cpu: "Shared" },
  { name: "10 GB", price: "Rp20.000", ram: "10 GB", cpu: "Shared" },
  { name: "Unlimited", price: "Rp25.000", ram: "Unlimited*", cpu: "Priority", best: true },
];

export const PLAN_FEATURES = (p) => [
  `${p.ram} RAM`,
  `${p.cpu} CPU`,
  "NVMe Storage",
  "Pterodactyl Panel",
  "Garansi 30 Hari",
];

export const BENCH = [
  ["hl", "# Bench.sh Result"],
  ["k", "CPU Model   ", ": Intel(R) Xeon(R) Gold 6133"],
  ["k", "CPU Cores   ", ": 8 @ 2494.140 MHz"],
  ["k", "CPU Cache   ", ": 28160 KB | AES-NI: Enabled"],
  ["k", "RAM / Disk  ", ": 62.8 GB / 249.5 GB"],
  ["k", "OS          ", ": Ubuntu 24.04.4 LTS"],
  ["k", "Virt / Arch ", ": VMware | x86_64"],
  ["k", "Location    ", ": Madiun / East Java"],
  ["ok", "I/O Speed Avg: 722.7 MB/s"],
  ["k", "Load        ", ": 0.04, 0.09, 0.08"],
];

export const SPEC_BLOCKS = [
  { title: "Processor", items: [
    "CPU Model: Intel(R) Xeon(R) Gold 6133 CPU @ 2.50GHz",
    "CPU Cores: 8 @ 2494.140 MHz",
    "CPU Cache: 28160 KB",
    "AES-NI: Enabled",
    "VM-x/AMD-V: Disabled",
  ]},
  { title: "Memory & storage", items: [
    "Total Disk: 249.5 GB (Used: 12.4 GB)",
    "Total RAM: 62.8 GB (Used: 1.4 GB)",
    "Total Swap: 4.0 GB (Used: 0 KB)",
  ]},
  { title: "System information", items: [
    "OS: Ubuntu 24.04.4 LTS",
    "Architecture: x86_64 (64 Bit)",
    "Kernel: 6.8.0-137-generic",
    "Virtualization: VMware",
    "IPv4: Online | IPv6: Offline",
  ]},
  { title: "Network & performance", items: [
    "Organization: AS139952 PT Trisari Data Indonusa",
    "Location: Madiun / Indonesia (East Java)",
    "I/O Speed Avg: 722.7 MB/s",
    "Load Average: 0.04, 0.09, 0.08",
  ]},
];

export const INFRA = [
  ["cpu", "Intel Xeon Gold 6133", "Enterprise-grade processor with 8 cores"],
  ["box", "VMware Virtualization", "Stable and isolated virtual environment"],
  ["monitor", "Ubuntu 24.04.4 LTS", "Modern, secure and long-term support OS"],
  ["hard-drive", "NVMe Storage", "High-speed storage infrastructure"],
  ["map-pin", "East Java Location", "Low latency for Indonesian users"],
  ["server", "Pterodactyl Official", "Official Pterodactyl panel installation"],
];

export const SECURITY = [
  ["server", "Server Infrastructure", "Enterprise grade hardware"],
  ["box", "VMware Virtualization", "Isolated & stable environment"],
  ["monitor", "Pterodactyl Official", "Official panel installation"],
  ["hard-drive", "NVMe Storage", "High speed storage layer"],
  ["shield", "Ubuntu Server", "Secure LTS operating system"],
  ["activity", "Server Monitoring", "Infrastructure management"],
];

export const RESELLER = {
  signup: "Rp40.000",
  monthly: "Rp10.000",
  perks: [
    "Akses reseller panel",
    "Hak menjual kembali layanan",
    "Harga khusus reseller",
    "Potensi margin penjualan",
  ],
};

export const DEMO_LOGS = [
  ["t", "[Pterodactyl Daemon]", "Checking server configuration…"],
  ["g", "[Pterodactyl Daemon]", "Server marked as running"],
  ["t", "[INFO]", "Bot connected to WhatsApp"],
  ["t", "[INFO]", "Memory usage stable"],
  ["g", "[INFO]", "Health check passed"],
  ["t", "[INFO]", "Backup schedule: ok"],
  ["t", "[INFO]", "Listening on port 25565"],
  ["g", "[INFO]", "Heartbeat received"],
];
